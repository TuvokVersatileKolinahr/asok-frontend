var less = {};
less.strictMath = false;
less.strictUnits = false;


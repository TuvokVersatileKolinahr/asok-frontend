describe("less.js postProcessor", function() {
  testLessEqualsInDocument();
});
